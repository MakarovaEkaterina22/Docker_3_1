class UpdateProjectProgressJob
    include Sidekiq::Worker
  
    def perform
      Project.all.each do |project|
        if project.status == "inactive"
          # Если статус "inactive", проставляем прогресс 100
          project.update(progress: 100)
        elsif project.status == "active"
          # Если статус "active", увеличиваем прогресс на случайное значение
          new_progress = project.progress + rand(1..10)
          new_progress = 100 if new_progress > 100 # Не превышаем 100%
          project.update(progress: new_progress)
        end
      end
    end
  end